host = '192.168.1.32';// hostname or IP address
port = 9001;
topic = 'Aig/Cde'; 
path = '/mqtt'
useTLS = false;
username = null;
password = null;
// username = "xxx";
// password = "aaa";

// path as in "scheme:[//[user:password@]host[:port]][/]path[?query][#fragment]"
//    defaults to "/mqtt"
//    may include query and fragment

cleansession = true;
